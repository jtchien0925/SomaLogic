# --------------------
# Revision Info
# --------------------
# $Revision: 14917 $
# $Author: sfield $
# $LastChangedDate: 2014-05-07 17:26:20 -0600 (Wed, 07 May 2014) $
# $URL: svn://kong.sladmin.com/svn-repository/BioInformatics/R/trunk/SomaGlobals/R/is.class.R $
#######################################
#			Function:	is.class
#######################################
is.class <- function(x, type) type %in% class(x)
#### ---- END FUNCTION ---- ####

# ---- saved on: 2013-10-21 10:57:36